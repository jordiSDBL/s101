package n1ex3;

public class Vehicle {
	/**
	 * bloc d'inicialitzaci� static 
	 * Nom�s es crida una vegada, quan es carrega la
	 * classe en mem�ria. �s el primer en carregar-se.
	 */
	static {
		System.out.println("Bloc d'inicialitzaci� static.");
	}

	/**
	 * bloc d'inicialitzaci� no static 
	 * Es carrega cada vegada que s'instancia un objecte de la classe. 
	 * Ho fa despr�s de carregar el bloc static la primera vegada i en primer lloc la resta de cops.
	 */
	{
		System.out.println("Bloc d'inicialitzaci� no static.");
	}

	/**
	 * constructor 
	 * Despr�s dels blocs d'inicialitzaci� es carrega el constructor de la classe.
	 */
	public Vehicle() {
		System.out.println("Constructor.");
	}
}
