package n1ex2;

public class Vehicle {
	//constructor
	public Vehicle() {
		System.out.println("S'ha creat un nou objecte de la classe Vehicle.");
	}

	//m�tode din�mic
	public void iniciar() {
		System.out.println("Cridem el m�tode iniciar de l'objecte de la classe Vehicle.");
	}

	//m�tode static
	public static void parar() {
		System.out.println("Crida al m�tode static parar() a nivell de classe Vehicle.");
	}

	//m�tode din�mic
	public void accelerar() {
		System.out.println("Cridem el m�tode din�mic accelerar() des d'una inst�ncia de la classe Vehicle.");
	}
}
