package n1ex6;

public class Amphibian {
	//atributs
	protected String nom;
	protected boolean cua;
	protected int numPotes;
	
	//constructor
	public Amphibian(String nom, boolean cua, int numPotes) {
		this.nom = nom;
		this.cua = cua;
		this.numPotes = numPotes;
	}
	
	//m�todes
		public boolean tePotes(int numPotes) {
			boolean tePotes = false;
			if (numPotes > 0)
				tePotes = true;
			return tePotes;
		}

		public boolean teCua(boolean cua) {
			boolean teCua = false;
			if (cua == true)
				teCua = true;
			return teCua;
		}

		public boolean esHibrid() {
			boolean esmix = false;
			if (teCua(cua) && tePotes(numPotes))
				esmix = true;
			return esmix;
		}

	//getters i setters
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public boolean isCua() {
		return cua;
	}

	public void setCua(boolean cua) {
		this.cua = cua;
	}

	public int getNumPotes() {
		return numPotes;
	}

	public void setNumPotes(int numPotes) {
		this.numPotes = numPotes;
	}	
}
