package n1ex6;

public class Frog extends Amphibian{
	//atribut
	private String color;

	//constuctor
	public Frog(String nom, boolean cua, int numPotes, String color) {
		super(nom, cua, numPotes);
		this.color = color;
	}

	//getters i setters
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
}
