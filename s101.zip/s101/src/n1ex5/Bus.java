package n1ex5;

public class Bus extends Vehicle{
	private int capacitat;
	
	public Bus() {
		super();
	}
	public Bus(String propietari) {
		super(propietari);
	}
	public Bus (String propietari, String color, int numPortes) {
		super(propietari, color, numPortes);
	}

	public Bus(String propietari, String color, int numPortes, int capacitat) {
		super(propietari, color, numPortes);
		this.capacitat = capacitat;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("\nBus:\nCapacitat = ");
		builder.append(capacitat);
		builder.append("\n");
		builder.append(super.toString());
		return builder.toString();
	}	
}
