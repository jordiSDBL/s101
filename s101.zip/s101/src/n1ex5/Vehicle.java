package n1ex5;

public class Vehicle {
	//atributs
	protected String propietari;
	protected String color;
	protected int numPortes;
	
	//constructors
	public Vehicle() {
		System.out.println("Constructor buit Vehicle");
	}
	public Vehicle(String propietari) {
		this.propietari = propietari;
		System.out.println("Constructor propietari Vehicle");
	}
	public Vehicle (String propietari, String color, int numPortes) {
		this.propietari = propietari;
		this.color = color;
		this.numPortes = numPortes;
		System.out.println("Constructor complet Vehicle");
	}
	
	//toString
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Propietari = ");
		builder.append(propietari);
		builder.append("\nColor = ");
		builder.append(color);
		builder.append("\nPortes = ");
		builder.append(numPortes);
		return builder.toString();
	}	
}
