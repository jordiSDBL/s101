package n1ex7;

public class Frog extends Amphibian {
	// atribut
	private String color;

	// constuctor
	public Frog(String nom, boolean cua, int numPotes, String color) {
		super(nom, cua, numPotes);
		this.color = color;
	}

	/**
	 * M�todes sobreescrits
	 * Inverteixo els outputs els tenen girats respecte dels de la classe pare
	 * per detectar a on es dirigeix la crida dels m�todes
	 */
	@Override
	public boolean tePotes(int numPotes) {
		boolean tePotes = false;
		if (numPotes <= 0)
			tePotes = true;
		return tePotes;
	}
	@Override
	public boolean teCua(boolean cua) {
		boolean teCua = true;
		if (cua == true)
			teCua = false;
		return teCua;
	}
	@Override
	public boolean esHibrid() {
		boolean esmix = true;
		if (teCua(cua) && tePotes(numPotes))
			esmix = false;
		return esmix;
	}

	// getters i setters
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
