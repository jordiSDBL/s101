package n1ex1;

public class Vehicle {
	//constructor
	public Vehicle() {
		System.out.println("S'ha creat un nou objecte de la classe Vehicle.");
	}

	//m�tode din�mic
	public void iniciar() {
		System.out.println("Cridem el m�tode iniciar de l'objecte de la classe Vehicle.");
	}
}
