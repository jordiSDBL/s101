package test;

import n1ex4.Vehicle;

public class Testn1ex4 {
	public static void main(String[] args) {
		Vehicle vehicle1 = new Vehicle();
		Vehicle vehicle2 = new Vehicle();

		System.out.println(vehicle1.toString());
		System.out.println(vehicle2.toString());

	}
}
