package test;

import n1ex1.Vehicle;

public class Testn1ex1 {

	public static void main(String[] args) {
		Vehicle vehicle1 = new Vehicle();
		vehicle1.iniciar();		
	}
}
