package test;

import n1ex7.Amphibian;
import n1ex7.Frog;

public class Testn1ex7 {
	public static void main(String[] args) {
		Frog frog = new Frog("Granota", false, 4, "verd");
		Amphibian amfibi = frog;

		System.out.println("�s un animal hibrid? " + amfibi.esHibrid());
		System.out.println("T� cua? " + amfibi.teCua(amfibi.isCua()));
		System.out.println("T� potes? " + amfibi.tePotes(amfibi.getNumPotes()));
		
		/**
		 * Tot i que l'objecte frog est� guardat a una variable de tipus Amphibian
		 * en cridar els m�todes primer mira si els troba a la classe del tipus que
		 * �s l'objecte, en aquest de la classe Frog ja que hem fet servir el seu
		 * constructor
		 */
	}
}
