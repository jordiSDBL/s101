package test;

import n1ex6.Amphibian;
import n1ex6.Frog;

public class Testn1ex6 {
	public static void main(String[] args) {
		Frog frog = new Frog("Granota", false, 4, "verd");
		Amphibian amfibi = frog;

		System.out.println("�s un animal hibrid? " + amfibi.esHibrid());
		System.out.println("T� cua? " + amfibi.teCua(amfibi.isCua()));
		System.out.println("T� potes? " + amfibi.tePotes(amfibi.getNumPotes()));
	}
}
