package test;

import n1ex5.Bus;

public class Testn1ex5 {
	public static void main(String[] args) {
		Bus bus1 = new Bus();
		Bus bus2 = new Bus("Marc");
		Bus bus3 = new Bus("Laura", "negre", 2);
		Bus bus4 = new Bus("Pau", "groc", 4, 75);
		System.out.println(bus1.toString());
		System.out.println(bus2.toString());
		System.out.println(bus3.toString());
		System.out.println(bus4.toString());
	}
}
