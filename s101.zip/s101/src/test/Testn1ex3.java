package test;

import n1ex3.Vehicle;

public class Testn1ex3 {
	public static void main(String[] args) {
		new Vehicle();
		new Vehicle();
	}
}
