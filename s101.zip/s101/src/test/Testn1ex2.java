package test;

import n1ex2.Vehicle;

public class Testn1ex2 {

	public static void main(String[] args) {
		Vehicle vehicle2 = new Vehicle();
		vehicle2.accelerar();
		Vehicle.parar();
	}
}
