package n1ex4;

public class Vehicle {
	//atributs
	public static final String MARCA = "SEAT";
	private final int idVehicle;
	private static int comptadorVehicles;

	//constructor
	public Vehicle() {
		++comptadorVehicles; // es pot inicialitzar
		this.idVehicle = comptadorVehicles; // es pot inicialitzar
		// MARCA = "Seat"; no es pot inicialitzar una constant en un constructor
	}
	//getters i setters
	public static int getComptadorVehicles() {return comptadorVehicles;}
	public static String getMarca() {return MARCA;}
	public int getIdVehicle() {return idVehicle;}

	//toString
	@Override
	public String toString() {
		return "Num.ID: " + this.idVehicle + "\nMarca: " + getMarca() + "\nTotal de vehicles: " + comptadorVehicles + "\n";
	}
	
	
	
	

}
